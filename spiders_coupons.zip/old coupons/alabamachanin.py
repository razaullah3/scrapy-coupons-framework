import csv
import datetime
import re
import scrapy
from scrapy.utils.response import open_in_browser
from ..items import couponsDealsItem
from ..GetDeals import DealsPicker
from ..Oprfunction import Textfunctions
from ..GetOtherDeals import OtherDealsPicker
import validators

class alabamachaninSpider(scrapy.Spider):
    name = 'alabamachanin'
    start_urls = ['https://alabamachanin.com/']
    productsurls = []
    nextpage = 0
    nvurl = []
    nvurlscounter = 0
    sitename = 'alabama_chanin'
    def parse(self, response):
        # open_in_browser(response)
        xp = DealsPicker()
        obj1 = OtherDealsPicker()
        xf = Textfunctions()
        item = couponsDealsItem()
        item['getDoc'] = 'true'
        item['SiteName'] = self.sitename
        yield item
        item['getDoc'] = ''
        notAllow = []
        Dls = []
        # if 'student' in response.url:
        #     Dls = obj1.Adidas(response, response.url)
        Deals = xp.Data_Collector(response, response.url, notAllow)
        if len(Dls) > 0:
            Deals.extend(Dls)
        for d in Deals:
            item['Title'] = str(d[0]).replace('Check Your Balance','')
            item['PromotionalText'] = d[1]
            item['SourceUrl'] = d[2]
            item['Image'] = d[3]
            item['Code'] = d[4]
            item['Offer'] = d[6]
            item['StartTime'] = 'None'
            item['EndTime'] = 'None'
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['SiteURL'] = response.url
            item['Type'] = d[13]
            item['SubType'] = d[14]
            item['Category'] = 'Apparel & Accessories'
            item['SubCategory'] = 'clothing'
            if str(item['Code']) != 'None' and 'coupon' not in str(item['Type']).lower():
                item['Type'] = 'Coupon'
            item['Status'] = 'Online'
            item['Framework'] = d[8]
            if response.url == self.start_urls[0]:
                self.nvurl = d[9]
            item['Preority'] = d[10]
            item['City'] = 'None'
            item['dealpage'] = 'true'
            yield item
        if len(self.nvurl) > 0:
            yield response.follow(self.nvurl[self.nvurlscounter], callback=self.NevigationUrls, dont_filter=True)
        item['dealpage'] = ''
        item['alllogs'] = 'true'
        yield item

    def NevigationUrls(self, response):
        # open_in_browser(response)
        xp = DealsPicker()
        obj1 = OtherDealsPicker()
        xf = Textfunctions()
        item = couponsDealsItem()
        item['getDoc'] = 'true'
        item['SiteName'] = self.sitename
        yield item
        item['getDoc'] = ''
        notAllow = []
        Deals = xp.Data_Collector(response, response.url, notAllow)
        for d in Deals:
            item['Title'] = d[0]
            item['PromotionalText'] = d[1]
            item['SourceUrl'] = d[2]
            item['Image'] = d[3]
            item['Code'] = d[4]
            item['Offer'] = d[6]
            item['StartTime'] = 'None'
            item['EndTime'] = 'None'
            item['DateAdded'] = datetime.datetime.now()
            item['DateUpdated'] = datetime.datetime.now()
            item['SiteURL'] = str(response.url).split('.com')[0]+'.com'
            item['Type'] = d[13]
            item['SubType'] = d[14]
            item['Status'] = 'Online'
            item['Framework'] = d[8]
            item['Preority'] = d[10]
            item['City'] = 'None'
            item['dealpage'] = 'true'
            yield item
        item['dealpage'] = ''
        item['alllogs'] = 'true'
        yield item
        self.nvurlscounter += 1
        if self.nvurlscounter < len(self.nvurl):
            yield response.follow(self.nvurl[self.nvurlscounter], callback=self.NevigationUrls, dont_filter=True)

    def close(spider, reason):
        print(reason)
        item = couponsDealsItem()
        item['dealpage'] = ''
        item['alllogs'] = 'true'
        yield item